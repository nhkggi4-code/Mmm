package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Base Canvas & Surfaces (Obsidian & Deep Slate #0B0E14)
val RoyalNavyDark = Color(0xFF0B0E14)       // Primary canvas background
val RoyalMidnight = Color(0xFF0F141F)       // Deep slate surface
val RoyalBlueDark = Color(0xFF161E2E)       // Dark card background
val RoyalBlue = Color(0xFF1E293B)           // Slate 800 secondary surface
val RoyalBlueMedium = Color(0xFF25334A)     // Elevated slate container
val RoyalBlueLight = Color(0xFF3B82F6)      // Accent blue
val RoyalBlueAccent = Color(0xFF60A5FA)     // Light blue indicator / link

// Sophisticated Gold Palette (#EAB308 & #FDE047)
val LegendGold = Color(0xFFEAB308)          // Primary gold accent
val LegendGoldBright = Color(0xFFFDE047)    // Highlight radiant gold
val LegendGoldLight = Color(0xFFFEF08A)     // Light gold text
val LegendGoldDark = Color(0xFFCA8A04)      // Dark gold amber
val LegendGoldContainer = Color(0x33EAB308) // 20% opacity gold pill container
val LegendGoldGlow = Color(0x40EAB308)      // Glow overlay

// Chat Bubbles & Surfaces
val ChatBgDark = Color(0xFF0B0E14)
val SentBubbleBg = Color(0xFF1E293B)        // Sophisticated slate 800 sent bubble
val SentBubbleGoldBorder = Color(0x33EAB308) // Subtle gold accent border
val ReceivedBubbleBg = Color(0xFF131924)    // Sophisticated deep slate received bubble
val ReceivedBubbleBorder = Color(0xFF1E293B) // Slate 800 border

val CardSurfaceDark = Color(0xFF131924)     // Sophisticated dark card surface
val CardSurfaceElevated = Color(0xFF1E293B) // Elevated card surface
val TopBarSurface = Color(0xFF0B0E14)       // Header dark background
val BottomNavSurface = Color(0xFF131924)    // Bottom navigation bar background

// Accents & Functional
val OnlineGreen = Color(0xFF22C55E)         // Green 500 indicator
val LegendRed = Color(0xFFEF4444)
val StatusSeenBorder = Color(0xFF64748B)
val StatusUnseenBorder = Color(0xFFEAB308)

// Text Colors (Tailwind Slate hierarchy)
val TextPrimary = Color(0xFFF8FAFC)         // Slate 100
val TextSecondary = Color(0xFF94A3B8)       // Slate 400
val TextMuted = Color(0xFF64748B)           // Slate 500
val TextGold = Color(0xFFEAB308)            // Gold text

// Gradients & Overlays
val DarkOverlay = Color(0xD90B0E14)         // 85% opacity dark overlay
val DividerColor = Color(0xFF1E293B)        // Slate 800 divider/border


