package com.example.ui.screens.call

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.LegendAvatar
import com.example.ui.components.formatCallDuration
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.DarkOverlay
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.LegendRed
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalMidnight
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun CallScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()

    if (activeCall == null) return
    val call = activeCall!!

    val transition = rememberInfiniteTransition(label = "call_pulse")
    val waveScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RoyalNavyDark)
    ) {
        if (call.isVideo && !call.isVideoOff) {
            // Video Feed simulation background
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = call.contactAvatarRes ?: R.drawable.img_legend_avatar),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dark subtle gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    RoyalNavyDark.copy(alpha = 0.85f),
                                    Color.Transparent,
                                    RoyalNavyDark.copy(alpha = 0.9f)
                                )
                            )
                        )
                )

                // Self Camera Pip (Picture-in-picture)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CardSurfaceDark,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 48.dp, end = 20.dp)
                        .size(width = 100.dp, height = 140.dp)
                        .border(2.dp, LegendGoldBright, RoundedCornerShape(16.dp))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.img_legend_avatar),
                            contentDescription = "أنا",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("أنت 👑", color = LegendGoldBright, fontSize = 10.sp)
                        }
                    }
                }
            }
        } else {
            // Voice Call Background Graphic
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                // Outer Pulse Ring
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .scale(waveScale)
                        .clip(CircleShape)
                        .background(LegendGold.copy(alpha = 0.12f))
                )

                // Middle Ring
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .background(RoyalBlueMedium.copy(alpha = 0.3f))
                )

                // Main Avatar
                LegendAvatar(
                    name = call.contactName,
                    avatarRes = call.contactAvatarRes,
                    size = 130.dp,
                    isVip = true
                )
            }
        }

        // Top Information Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 56.dp, start = 20.dp, end = 20.dp)
        ) {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.7f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.border(1.dp, LegendGold.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "تشفير تام",
                        tint = LegendGoldBright,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "مشفرة تماماً بنظام واتساب الاسطورة الملكي",
                        color = LegendGoldLight,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = call.contactName,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (call.isConnected) {
                    "متصل • ${formatCallDuration(call.durationSeconds)}"
                } else {
                    "جاري الرنين والاتصال بالأجهزة الملكية..."
                },
                color = if (call.isConnected) LegendGoldBright else RoyalBlueAccent,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }

        // Bottom Controls Bar
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp, start = 24.dp, end = 24.dp)
        ) {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.95f),
                shape = RoundedCornerShape(32.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DividerColor, RoundedCornerShape(32.dp))
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    // Mute Mic Toggle
                    CallControlButton(
                        icon = if (call.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        isActive = call.isMuted,
                        label = if (call.isMuted) "كتم" else "صامت",
                        onClick = { viewModel.toggleMuteCall() }
                    )

                    // Video Toggle
                    if (call.isVideo) {
                        CallControlButton(
                            icon = if (call.isVideoOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                            isActive = call.isVideoOff,
                            label = if (call.isVideoOff) "إيقاف" else "الكاميرا",
                            onClick = { viewModel.toggleVideoOff() }
                        )

                        CallControlButton(
                            icon = Icons.Default.Cameraswitch,
                            isActive = false,
                            label = "قلب",
                            onClick = { viewModel.switchCamera() }
                        )
                    } else {
                        // Speaker Toggle
                        CallControlButton(
                            icon = if (call.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                            isActive = call.isSpeakerOn,
                            label = if (call.isSpeakerOn) "مكبر الصوت" else "سماعة",
                            onClick = { viewModel.toggleSpeaker() }
                        )
                    }

                    // End Call Button
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(LegendRed)
                            .clickable { viewModel.endCall() }
                            .testTag("btn_end_call")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "إنهاء المكالمة",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CallControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (isActive) LegendGold else CardSurfaceElevated)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) RoyalNavyDark else TextPrimary,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.sp
        )
    }
}
