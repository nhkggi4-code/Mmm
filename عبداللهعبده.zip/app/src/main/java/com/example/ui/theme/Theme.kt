package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LegendColorScheme = darkColorScheme(
    primary = LegendGold,
    onPrimary = RoyalNavyDark,
    primaryContainer = LegendGoldContainer,
    onPrimaryContainer = LegendGoldLight,
    secondary = RoyalBlueAccent,
    onSecondary = RoyalNavyDark,
    secondaryContainer = RoyalBlueMedium,
    onSecondaryContainer = TextPrimary,
    tertiary = LegendGoldBright,
    onTertiary = RoyalNavyDark,
    background = RoyalNavyDark,
    onBackground = TextPrimary,
    surface = RoyalMidnight,
    onSurface = TextPrimary,
    surfaceVariant = CardSurfaceDark,
    onSurfaceVariant = TextSecondary,
    outline = DividerColor,
    outlineVariant = RoyalBlueDark,
    error = LegendRed,
    onError = TextPrimary
)

private val LegendLightColorScheme = lightColorScheme(
    primary = RoyalBlueMedium,
    onPrimary = TextPrimary,
    primaryContainer = RoyalBlueDark,
    onPrimaryContainer = LegendGoldLight,
    secondary = LegendGoldDark,
    onSecondary = TextPrimary,
    secondaryContainer = LegendGoldLight,
    onSecondaryContainer = RoyalNavyDark,
    tertiary = LegendGold,
    background = RoyalNavyDark, // WhatsApp Legend defaults to luxurious royal dark aesthetic
    onBackground = TextPrimary,
    surface = RoyalMidnight,
    onSurface = TextPrimary,
    surfaceVariant = CardSurfaceDark,
    onSurfaceVariant = TextSecondary,
    outline = DividerColor,
    error = LegendRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to royal dark for gold/blue richness
    dynamicColor: Boolean = false, // Keep brand royal blue and gold consistent
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) LegendColorScheme else LegendLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = TopBarSurface.toArgb()
            window.navigationBarColor = BottomNavSurface.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = false
            insetsController.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun LegendTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MyApplicationTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}


