package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LegendAvatar(
    name: String,
    avatarRes: Int? = null,
    avatarUrl: String? = null,
    size: Dp = 52.dp,
    isOnline: Boolean = false,
    isVip: Boolean = false,
    hasStory: Boolean = false,
    isStoryViewed: Boolean = false,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size + (if (hasStory) 6.dp else 0.dp))
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            )
    ) {
        // Story ring if applicable
        if (hasStory) {
            val storyBrush = if (isStoryViewed) {
                Brush.sweepGradient(listOf(Color(0xFF64748B), Color(0xFF94A3B8), Color(0xFF64748B)))
            } else {
                Brush.sweepGradient(listOf(LegendGoldBright, RoyalBlueAccent, LegendGold, LegendGoldBright))
            }
            Box(
                modifier = Modifier
                    .size(size + 6.dp)
                    .clip(CircleShape)
                    .background(storyBrush)
            )
        }

        // Inner Avatar Box
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(CardSurfaceElevated, CardSurfaceDark, RoyalNavyDark)
                    )
                )
                .border(
                    width = if (isVip) 2.dp else 1.5.dp,
                    brush = if (isVip) Brush.linearGradient(listOf(LegendGoldBright, LegendGold, LegendGoldDark))
                    else Brush.linearGradient(listOf(LegendGold.copy(alpha = 0.4f), Color.Transparent)),
                    shape = CircleShape
                )
        ) {
            if (avatarRes != null) {
                androidx.compose.foundation.Image(
                    painter = painterResource(id = avatarRes),
                    contentDescription = name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(size)
                )
            } else if (!avatarUrl.isNullOrEmpty()) {
                AsyncImage(
                    model = avatarUrl,
                    contentDescription = name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(size)
                )
            } else {
                // Initial Letter
                val initial = name.trim().take(1).uppercase(Locale.getDefault())
                Text(
                    text = if (initial.isNotEmpty()) initial else "م",
                    color = LegendGold,
                    fontSize = (size.value * 0.42f).sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Online Badge
        if (isOnline) {
            Box(
                modifier = Modifier
                    .size(size * 0.28f)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(OnlineGreen)
                    .border(2.dp, RoyalNavyDark, CircleShape)
            )
        }

        // Crown Badge for VIP / "الاسطورة محمد"
        if (isVip) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(size * 0.36f)
                    .align(Alignment.TopStart)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(LegendGoldBright, LegendGoldDark)
                        )
                    )
                    .border(1.dp, Color.White, CircleShape)
            ) {
                Text(
                    text = "👑",
                    fontSize = (size.value * 0.22f).sp
                )
            }
        }
    }
}

@Composable
fun MessageStatusTicks(
    status: String,
    modifier: Modifier = Modifier
) {
    when (status) {
        "READ" -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "تمت القراءة",
                tint = LegendGoldBright,
                modifier = modifier.size(17.dp)
            )
        }
        "DELIVERED" -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "تم التسليم",
                tint = TextSecondary,
                modifier = modifier.size(17.dp)
            )
        }
        "SENT" -> {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "تم الإرسال",
                tint = TextSecondary,
                modifier = modifier.size(16.dp)
            )
        }
        else -> {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "جاري الإرسال",
                tint = TextMuted,
                modifier = modifier.size(15.dp)
            )
        }
    }
}

@Composable
fun UnreadBadge(
    count: Int,
    modifier: Modifier = Modifier
) {
    if (count <= 0) return
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(LegendGold, LegendGoldDark)
                )
            )
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(
            text = if (count > 99) "99+" else count.toString(),
            color = RoyalNavyDark,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
fun LegendShieldBanner(
    modifier: Modifier = Modifier
) {
    Surface(
        color = CardSurfaceDark.copy(alpha = 0.8f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, LegendGold.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "تشفير تام",
                tint = LegendGold,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "الرسائل والمكالمات مشفرة تماماً بين الطرفين بتقنية الاسطورة الملكية 🛡️",
                color = LegendGoldLight,
                fontSize = 11.sp,
                lineHeight = 14.sp
            )
        }
    }
}

fun formatChatTimestamp(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    val oneDay = 24 * 60 * 60 * 1000L

    return when {
        diff < 60 * 1000L -> "الآن"
        diff < oneDay -> SimpleDateFormat("h:mm a", Locale("ar")).format(Date(timestamp))
        diff < 2 * oneDay -> "أمس"
        else -> SimpleDateFormat("dd/MM/yyyy", Locale("ar")).format(Date(timestamp))
    }
}

fun formatCallDuration(seconds: Int): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
