package com.example.ui.screens.status

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.LegendAvatar
import com.example.ui.components.formatChatTimestamp
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalMidnight
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun StatusViewerScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val status by viewModel.selectedStatus.collectAsStateWithLifecycle()
    if (status == null) return

    val currentStatus = status!!
    val progress = remember { Animatable(0f) }
    var replyText by remember { mutableStateOf("") }

    // Auto advance progress bar for 6 seconds
    LaunchedEffect(currentStatus.id) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 6000, easing = LinearEasing)
        )
        viewModel.closeStatus()
    }

    val bgColor = remember(currentStatus.bgColorHex) {
        try {
            Color(android.graphics.Color.parseColor(currentStatus.bgColorHex))
        } catch (e: Exception) {
            RoyalMidnight
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgColor)
            .clickable { viewModel.closeStatus() }
    ) {
        // Optional media image
        if (currentStatus.mediaRes != null) {
            Image(
                painter = painterResource(id = currentStatus.mediaRes!!),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dark gradient overlay for text readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent, Color.Black.copy(alpha = 0.8f))
                        )
                    )
            )
        }

        // Story Text Content Centered
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp)
        ) {
            Text(
                text = currentStatus.text,
                color = LegendGoldLight,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                textAlign = TextAlign.Center,
                lineHeight = 34.sp
            )
        }

        // Top Status Header & Progress Bar
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp)
        ) {
            // Segmented Progress Bar
            LinearProgressIndicator(
                progress = { progress.value },
                color = LegendGoldBright,
                trackColor = Color.White.copy(alpha = 0.3f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Author Info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { viewModel.closeStatus() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                LegendAvatar(
                    name = currentStatus.authorName,
                    avatarRes = currentStatus.authorAvatarRes,
                    size = 40.dp,
                    isVip = currentStatus.authorName.contains("الاسطورة")
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = currentStatus.authorName,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = formatChatTimestamp(currentStatus.timestamp),
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Bottom Reply Input
        if (!currentStatus.isMine) {
            Surface(
                color = Color.Black.copy(alpha = 0.7f),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .border(1.dp, LegendGold.copy(alpha = 0.4f), RoundedCornerShape(28.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        placeholder = { Text("الرد على الحالة...", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            if (replyText.isNotBlank()) {
                                viewModel.sendMessage("رد على الحالة: $replyText")
                                viewModel.closeStatus()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "إرسال الرد",
                            tint = LegendGoldBright
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusCreatorScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    var statusText by remember { mutableStateOf("") }
    val colorPalettes = listOf(
        "#0B192C", // Royal Midnight
        "#1E3E62", // Royal Blue
        "#2A2408", // Golden Deep
        "#064E3B", // Emerald
        "#4C1D95", // Deep Purple
        "#7F1D1D"  // Crimson
    )
    var selectedColorIndex by remember { mutableIntStateOf(0) }

    val currentBgColor = Color(android.graphics.Color.parseColor(colorPalettes[selectedColorIndex]))

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(currentBgColor)
            .padding(20.dp)
    ) {
        // Top Bar Controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 28.dp)
        ) {
            IconButton(
                onClick = { viewModel.closeStatus() },
                modifier = Modifier.testTag("btn_close_creator")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إلغاء",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Row {
                // Color Switcher
                IconButton(
                    onClick = {
                        selectedColorIndex = (selectedColorIndex + 1) % colorPalettes.size
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.ColorLens,
                        contentDescription = "تغيير اللون",
                        tint = LegendGoldBright,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Emoji Picker
                IconButton(
                    onClick = {
                        statusText += " 👑"
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEmotions,
                        contentDescription = "رموز",
                        tint = LegendGoldBright,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // Center Text Input
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            OutlinedTextField(
                value = statusText,
                onValueChange = { statusText = it },
                placeholder = {
                    Text(
                        text = "اكتب حالتك الملكية هنا...",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 24.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = LegendGoldLight,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("status_creator_input")
            )
        }

        // Send / Publish FAB
        FloatingActionButton(
            onClick = {
                if (statusText.isNotBlank()) {
                    viewModel.addStatus(statusText, colorPalettes[selectedColorIndex])
                }
            },
            containerColor = LegendGold,
            contentColor = RoyalNavyDark,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 24.dp, end = 8.dp)
                .testTag("btn_publish_status")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = "نشر الحالة"
            )
        }
    }
}
