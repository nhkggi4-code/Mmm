package com.example.data.models

enum class MessageType {
    TEXT,
    IMAGE,
    AUDIO,
    VIDEO,
    DOCUMENT,
    LOCATION,
    VOICE_NOTE,
    POLL
}

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallDirection {
    INCOMING,
    OUTGOING,
    MISSED
}

data class ContactItem(
    val id: String,
    val name: String,
    val phone: String,
    val avatarRes: Int? = null,
    val statusBio: String = "متاح على واتساب الاسطورة",
    val isVip: Boolean = false
)

data class PollOption(
    val id: Int,
    val text: String,
    val votes: Int = 0,
    val isVotedByMe: Boolean = false
)
